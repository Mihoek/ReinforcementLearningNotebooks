Pacman RL Project
=================

Contenu
-------
Ce dépôt contient l'implémentation des agents pour le projet de reinforcement learning (Value Iteration, Q-learning, Approximate Q-learning) et un utilitaire `record_to_gif.py` pour enregistrer des frames de l'affichage et convertir en GIF.

Usage rapide pour créer un GIF
-----------------------------
1. Installer ImageMagick (recommandé) ou Pillow+imageio pour la conversion des frames.
2. Lancer l'enregistrement d'une partie Pacman (ex. ApproximateQAgent) :

```powershell
cd "c:\Work&Projects\Machine_Learning\pacman\reinforcement"
python record_to_gif.py -p ApproximateQAgent -n 1 -l smallGrid
```

3. Le script crée un dossier `frames/` contenant des fichiers PostScript et tentera de générer `out.gif`.

Notes
-----
- Le script `record_to_gif.py` active temporairement la sauvegarde de PostScript dans `graphicsDisplay.py` et convertit les frames.
- Pour pousser vers un dépôt distant (GitHub), crée d'abord le repo distant puis exécute :

```powershell
git remote add origin <REMOTE_URL>
git push -u origin record-gif
```

Branch
------
Les changements ont été commités sur la branche non-main `record-gif`.

Auteur
------
Fichiers modifiés/ajoutés notables:
- `reinforcement/valueIterationAgents.py`
- `reinforcement/qlearningAgents.py`
- `reinforcement/record_to_gif.py`
- `reinforcement/graphicsDisplay.py` (ajout d'appel à `saveFrame()`)

Bonne exploration !
