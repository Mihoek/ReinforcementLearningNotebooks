# Livrable 2 - Projet Pac-man d'Apprentissage par Renforcement

Ce dossier contient le deuxième livrable du projet d'apprentissage par renforcement Pac-man, avec une amélioration des extracteurs de caractéristiques pour un meilleur apprentissage de l'agent.

## Nouvelles fonctionnalités d'extraction

Dans ce livrable, nous avons ajouté un nouvel extracteur de caractéristiques personnalisé appelé `CustomExtractor` qui enrichit les fonctionnalités disponibles pour l'agent d'apprentissage par rapport à l'extracteur simple du livrable précédent.

### CustomExtractor

Le `CustomExtractor` introduit les caractéristiques suivantes:

1. **Arrêt pénalisé**: Si l'action est `Directions.STOP`, l'extracteur retourne un compteur vide, décourageant l'agent à rester immobile.

2. **Coordonnées actuelles**: Les coordonnées x et y de Pacman sont incluses comme caractéristiques, permettant à l'agent de mieux comprendre sa position dans le labyrinthe.

3. **Possibilité de manger les fantômes**: Une caractéristique binaire (1.0 ou 0.0) qui indique si au moins un fantôme est actuellement effrayé (temps de peur > 0), permettant à l'agent de reconnaître les opportunités de manger des fantômes.

4. **Nourriture restante**: Le nombre de pastilles de nourriture restantes sur le plateau, aidant l'agent à évaluer son progrès global dans le jeu.

5. **Nourriture la plus proche**: Distance normalisée à la nourriture la plus proche depuis la position que Pacman atteindra après avoir exécuté l'action choisie.

Toutes ces caractéristiques sont normalisées (divisées par 10.0) pour garantir une convergence stable de l'apprentissage.

## Avantages par rapport à SimpleExtractor

Le `CustomExtractor` offre plusieurs avantages par rapport à `SimpleExtractor`:

1. **Conscience spatiale améliorée**: En utilisant les coordonnées actuelles, l'agent peut apprendre des comportements spécifiques à certaines régions du labyrinthe.

2. **Planification stratégique**: La connaissance du nombre total de nourritures restantes permet à l'agent de développer des stratégies plus globales.

3. **Exploitation des vulnérabilités des fantômes**: L'agent peut apprendre à chasser activement les fantômes effrayés au lieu de simplement les éviter.

4. **Prévention de la stagnation**: La pénalisation des actions d'arrêt encourage un comportement plus dynamique et efficace.

