# GridWorld Reinforcement Learning Framework

## Prérequis

Librairies requises :
```bash
pip install numpy matplotlib ipython jupyter
```

## Comment Exécuter le Notebook

### 1. Configuration initiale
Exécutez les cellules 1-8 dans l'ordre

### 2. Agents d'apprentissage par renforcement
Exécutez les cellules 13-17

### 3. Entraînement et comparaison
Exécutez les cellules 18-21 :
- Cellule 19 : PRINCIPALE - Entraîne tous les agents et affiche les résultats
- Cellule 20 : Graphiques comparatifs et politiques
- Cellule 21 : Test détaillé d'un agent spécifique

## Configuration des Paramètres

Dans la cellule 19 :
```python
TRAINING_EPISODES = 500    # Nombre d'épisodes d'entraînement
TEST_EPISODES = 100        # Nombre d'épisodes de test
```

Dans la cellule 21 :
```python
AGENT_TO_TEST = 'Q-Learning'  # Agent à tester
```